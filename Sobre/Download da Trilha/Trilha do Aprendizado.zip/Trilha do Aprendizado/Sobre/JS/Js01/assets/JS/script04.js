var numero;

numero = parseInt(prompt("Entre com um número: "));

if (numero % 2 == 0) {
    alert("O número é par.");
} else {
    alert("O número é ímpar.");
}