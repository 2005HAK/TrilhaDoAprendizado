prompt("Script JS em arquivo Externo");

var frase;

frase="Aqui temos uma String";

alert(frase);