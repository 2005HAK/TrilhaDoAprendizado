valor1 = prompt("Digite o valor 1: ");
valor2 = prompt("Digite o valor 2: ");

subtracao = parseInt(valor1) - parseInt(valor2);

alert(valor1+" - "+valor2+" = "+subtracao);