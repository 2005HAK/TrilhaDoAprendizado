n1 = prompt("Digite o valor 1: ");
n2 = prompt("Digite o valor 2: ");

soma = parseInt(n1) + parseInt(n2);

alert (n1+" + "+n2+" = "+soma);